"""
Unified transformation module that integrates character analysis and quality control.
This replaces the fragmented workflow with a single, cohesive transformation pipeline.
"""

import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from pathlib import Path

from api_client import UnifiedLLMClient
from .quality_control import quality_control_loop, validate_transformation
from .transform import transform_chapter
from .chunking import smart_chunk_sentences, estimate_tokens
from .chunking.model_configs import calculate_optimal_chunk_size, get_model_config

# Progress indicators
CYAN = '\033[96m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
BOLD = '\033[1m'
RESET = '\033[0m'


class UnifiedBookTransformer:
    """
    Unified transformer that handles the complete pipeline:
    1. Character analysis (mandatory)
    2. Gender transformation
    3. Quality control
    4. Validation and reporting
    """
    
    def __init__(self, provider: str = "openai", model: Optional[str] = None):
        """Initialize the unified transformer."""
        self.provider = provider
        self.model = model
        self.client = UnifiedLLMClient(provider)
    
    def _recreate_text_from_data(self, book_data: Dict[str, Any]) -> str:
        """Recreate text from book data dictionary (not from file)."""
        import re
        
        text_parts = []
        
        # Add metadata header if available
        metadata = book_data.get('metadata', {})
        if metadata.get('title') and metadata.get('title') != 'Unknown':
            text_parts.append(f"Title: {metadata.get('title')}")
        if metadata.get('author') and metadata.get('author') != 'Unknown':
            text_parts.append(f"Author: {metadata.get('author')}")
        if text_parts:
            text_parts.append('')  # Empty line after metadata
        
        # Process chapters
        for chapter in book_data.get('chapters', []):
            # Add chapter header
            chapter_header = []
            if chapter.get('number'):
                chapter_header.append(f"Chapter {chapter['number']}")
            if chapter.get('title'):
                if chapter_header:
                    chapter_header.append(f": {chapter['title']}")
                else:
                    chapter_header.append(chapter['title'])
            
            if chapter_header:
                text_parts.append(''.join(chapter_header))
                text_parts.append('')  # Empty line after chapter header
            
            # Process paragraphs
            for paragraph in chapter.get('paragraphs', []):
                # Join sentences in paragraph
                para_text = ' '.join(paragraph.get('sentences', []))
                if para_text:  # Only add non-empty paragraphs
                    text_parts.append(para_text)
                    text_parts.append('')  # Empty line between paragraphs
            
            # Extra line between chapters
            text_parts.append('')
        
        # Join all parts
        recreated_text = '\n'.join(text_parts)
        
        # Clean up excessive empty lines
        recreated_text = re.sub(r'\n{3,}', '\n\n', recreated_text)
        recreated_text = recreated_text.strip()
        
        return recreated_text
        
    def transform_book_with_qc(self, 
                              book_data: Dict[str, Any],
                              transform_type: str = "gender_swap",
                              verbose: bool = True,
                              output_path: Optional[str] = None,
                              dry_run: bool = False) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Transform a book with integrated quality control.
        Uses 1 QC iteration by default for faster processing.
        
        Args:
            book_data: Parsed JSON book data
            transform_type: Type of transformation (all_male, all_female, gender_swap)
            verbose: Print progress information
            output_path: Optional path to save both JSON and text output
            dry_run: If True, only process first chapter
            
        Returns:
            Tuple of (transformed_book_data, transformation_report)
        """
        
        start_time = time.time()
        report = {
            'start_time': datetime.now().isoformat(),
            'transform_type': transform_type,
            'stages': {}
        }
        
        if verbose:
            print(f"\n{CYAN}{'='*60}{RESET}")
            print(f"{CYAN}Starting Unified Transformation Pipeline{RESET}")
            print(f"{CYAN}{'='*60}{RESET}")
            print(f"📖 Book: {book_data.get('title', 'Unknown')}")
            print(f"🔄 Transform: {transform_type}")
            print()
        
        # Stage 1: Character Analysis (MANDATORY)
        if verbose:
            print(f"{BOLD}Stage 1: Character Analysis{RESET}")
        
        character_start = time.time()
        try:
            from book_characters import analyze_book_characters
            characters, character_context = analyze_book_characters(
                book_data, 
                model=self.model, 
                provider=self.provider, 
                verbose=verbose
            )
            
            if not characters:
                raise ValueError("No characters found in book")
                
            report['stages']['character_analysis'] = {
                'success': True,
                'characters_found': len(characters),
                'time_taken': time.time() - character_start
            }
            
            if verbose:
                print(f"  ✓ Found {len(characters)} characters")
            
            # Save character analysis immediately
            try:
                import os
                from book_characters.exporter import save_character_analysis
                
                # Save characters to a file immediately
                if output_path:
                    char_dir = os.path.dirname(output_path)
                    base_filename = os.path.basename(output_path)
                    # Ensure we handle both cases: with and without .json extension
                    if base_filename.endswith('.json'):
                        char_filename = base_filename.replace('.json', '_characters.json')
                    else:
                        char_filename = base_filename + '_characters.json'
                    char_path = os.path.join(char_dir, char_filename)
                    
                    metadata = {
                        "book_title": book_data.get('metadata', {}).get('title', 'Unknown'),
                        "total_characters": len(characters),
                        "provider": self.provider,
                        "model": self.model
                    }
                    
                    save_character_analysis(characters, char_path, metadata)
                    if verbose:
                        print(f"  💾 Character analysis saved to: {char_path}")
            except Exception as save_error:
                if verbose:
                    print(f"  ⚠️  Warning: Could not save character analysis: {save_error}")
                
        except Exception as e:
            report['stages']['character_analysis'] = {
                'success': False,
                'error': str(e),
                'time_taken': time.time() - character_start
            }
            
            # Character analysis is always mandatory
            raise RuntimeError(f"Character analysis failed: {e}")
        
        # Stage 2: Initial Transformation
        if verbose:
            print(f"\n{BOLD}Stage 2: Initial Transformation{RESET}")
        
        transform_start = time.time()
        transformed_chapters = []
        all_changes = []
        
        # In dry run mode, only process first chapter
        chapters_to_process = book_data['chapters'][:1] if dry_run else book_data['chapters']
        
        for idx, chapter in enumerate(chapters_to_process):
            if verbose:
                timestamp = datetime.now().strftime("%H:%M:%S")
                if dry_run:
                    print(f"[{timestamp}] Chapter {idx + 1}/{len(chapters_to_process)} (DRY RUN - first chapter only)", end='', flush=True)
                else:
                    print(f"[{timestamp}] Chapter {idx + 1}/{len(chapters_to_process)}", end='', flush=True)
            
            transformed_chapter, chapter_changes = transform_chapter(
                chapter,
                transform_type,
                character_context,
                model=self.model,
                provider=self.provider,
                verbose=False  # Suppress per-chapter output
            )
            
            transformed_chapters.append(transformed_chapter)
            all_changes.extend(chapter_changes)
            
            if verbose:
                print(f" ✓ ({len(chapter_changes)} changes)")
        
        report['stages']['initial_transform'] = {
            'success': True,
            'chapters_processed': len(transformed_chapters),
            'total_changes': len(all_changes),
            'time_taken': time.time() - transform_start
        }
        
        # Create initial transformed book
        transformed_book = book_data.copy()
        if dry_run:
            # In dry run, append untransformed chapters
            transformed_book['chapters'] = transformed_chapters + book_data['chapters'][1:]
        else:
            transformed_book['chapters'] = transformed_chapters
        
        # Initialize qc_changes_total for all paths
        qc_changes_total = 0
        
        # Stage 3: Quality Control (always run unless dry run)
        if not dry_run:
            if verbose:
                print(f"\n{BOLD}Stage 3: Quality Control{RESET}")
            
            qc_start = time.time()
            
            # Convert to text for QC
            transformed_text = self._recreate_text_from_data(transformed_book)
            
            # Run quality control (1 iteration by default for speed)
            cleaned_text, qc_changes = quality_control_loop(
                transformed_text,
                transform_type,
                model=self.model,
                provider=self.provider,
                max_iterations=1,
                verbose=verbose
            )
            
            qc_changes_total = len(qc_changes)
            
            # If QC made changes, update the book data
            if qc_changes:
                # This is simplified - in reality we'd need to map changes back to JSON structure
                # Note: We don't store the cleaned text to save memory
                # It can be regenerated from the JSON if needed
                pass
            
            report['stages']['quality_control'] = {
                'success': True,
                'issues_fixed': qc_changes_total,
                'iterations': 1,
                'time_taken': time.time() - qc_start
            }
        
        # Stage 4: Validation (skip in dry run since we only transformed first chapter)
        if not dry_run:
            if verbose:
                print(f"\n{BOLD}Stage 4: Validation{RESET}")
            
            val_start = time.time()
            
            # Get original text for comparison
            original_text = self._recreate_text_from_data(book_data)
            final_text = transformed_book.get('qc_text', self._recreate_text_from_data(transformed_book))
            
            validation_report = validate_transformation(
                original_text,
                final_text,
                transform_type,
                characters
            )
            
            report['stages']['validation'] = {
                'success': True,
                'quality_score': validation_report['quality_score'],
                'remaining_issues': validation_report['total_issues'],
                'time_taken': time.time() - val_start
            }
            
            if verbose:
                print(f"  Quality Score: {validation_report['quality_score']}/100")
                print(f"  Remaining Issues: {validation_report['total_issues']}")
        else:
            # In dry run, create a dummy validation report
            validation_report = {
                'quality_score': 'N/A (dry run)',
                'total_issues': 0,
                'message': 'Validation skipped in dry run mode'
            }
        
        # Add metadata to transformed book
        transformed_book['transformation'] = {
            'type': transform_type,
            'model': self.model,
            'provider': self.provider,
            'timestamp': datetime.now().isoformat(),
            'quality_level': 'standard',  # Using 1 QC iteration by default
            'total_changes': len(all_changes) + qc_changes_total,
            'character_analysis': characters,
            'validation': validation_report
        }
        
        # Stage 5: Output Generation
        if output_path:
            if verbose:
                print(f"\n{BOLD}Stage 5: Saving Output{RESET}")
            
            output_path = Path(output_path)
            
            # Save JSON
            json_path = output_path.with_suffix('.json')
            from book_parser import save_book_json
            save_book_json(transformed_book, str(json_path))
            
            # Save text
            text_path = output_path.with_suffix('.txt')
            # Get the final text - either from QC or from the transformed book
            if not dry_run and 'qc_text' in transformed_book:
                text_to_save = transformed_book['qc_text']
            else:
                text_to_save = self._recreate_text_from_data(transformed_book)
            
            with open(text_path, 'w', encoding='utf-8') as f:
                f.write(text_to_save)
            
            if verbose:
                print(f"  ✓ JSON saved to: {json_path}")
                print(f"  ✓ Text saved to: {text_path}")
        
        # Complete report
        total_time = time.time() - start_time
        report['total_time'] = total_time
        report['success'] = True
        
        if verbose:
            print(f"\n{GREEN}{'='*60}{RESET}")
            print(f"{GREEN}✓ Transformation Complete!{RESET}")
            print(f"{GREEN}{'='*60}{RESET}")
            print(f"⏱️  Total time: {total_time:.1f}s")
            print(f"📊 Quality score: {validation_report['quality_score']}/100")
            print(f"✏️  Total changes: {transformed_book['transformation']['total_changes']}")
        
        return transformed_book, report


def transform_book_unified(book_data: Dict[str, Any],
                         transform_type: str = "gender_swap",
                         model: Optional[str] = None,
                         provider: Optional[str] = None,
                         output_path: Optional[str] = None,
                         verbose: bool = True,
                         dry_run: bool = False) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Convenience function for unified book transformation.
    
    This is the main entry point that should be used for all transformations.
    """
    transformer = UnifiedBookTransformer(provider=provider or "openai", model=model)
    return transformer.transform_book_with_qc(
        book_data=book_data,
        transform_type=transform_type,
        verbose=verbose,
        output_path=output_path,
        dry_run=dry_run
    )